import React from "react";

const Koti = () => {
  return (
    <div>
      <h2>Moikka</h2>
      <p>Tähän tekstiä. Tähän tekstiä. Tähän tekstiä..</p>
    </div>
  );
};

export default Koti;
